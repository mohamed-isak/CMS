<?php
error_reporting(0);
session_start();

$connect = mysqli_connect('localhost','cms_construct','cms_construct','cms_construct');
  
/*if($connect)
{
	echo "connect";
	
}
else
{
	echo "failed";
}*/
?>

